-- name: Coop's Usamune
-- description: Welcome to Coop’s Usamune\n\nAn inspired mod of Usamune made by   \\#69A3FA\\J\\#74ACFB\\u\\#7FB5FC\\l\\#8ABDFC\\i\\#95C6FD\\u\\#A0CFfE\\s \\#dcdcdc\\and \\#ffa500\\JimmyNeutron\\#dcdcdc\\, featuring several improvements, custom options, and quality of life additions designed to make gameplay smoother and more enjoyable. This project aims to bring the feel and functionality of Usamune into a more modern and flexible setup while keeping it faithful to the original experience.\n\nSpecial Thanks to:\n \nBlocky, Mingokrb and Zlender for the menu template, input display, ghosts and PBs codes
-- pausable: false
-- incompatible: gamemode nametags
-- category: gamemode

djui_hud_set_resolution(RESOLUTION_N64)
screenW, screenH = djui_hud_get_screen_width(), djui_hud_get_screen_height()
isPaused = is_game_paused()

-- inMenu --
function load_setting(key)
	local value = mod_storage_load_number(key)
	if value == nil or value == 0 then
		mod_storage_save_number(key, 1) -- "OFF", "NONE", etc.
		value = mod_storage_load_number(key)
	end
	return value
end

function update_settings()
	-- menuINPUT
	c_input_stick = load_setting("m_1_STICK")
	c_input_buttons = load_setting("m_1_BUTTONS")
	c_input_stickbg = load_setting("m_1_STICKBG")
	c_input_axis = load_setting("m_1_A`IS")
end

function load_var(key, defVal)
	if not mod_storage_load_number(key) then
		if defVal then
			mod_storage_save_number(key, defVal)
		else
			mod_storage_save_number(key, 1)
		end
	end
	return mod_storage_load_number(key)
end

function update_vars()
	c_input_stickVar = load_var("m_1_STICK_var")
	c_input_buttonsVar = load_var("m_1_BUTTONS_var")
end

update_settings()
update_vars()

local tex_analog_base = {
	get_texture_info('analog_base'),
	get_texture_info('analog_base_rounded')
}
local tex_analog_stick = {
	get_texture_info('analog_stick'),
	get_texture_info('analog_stick_large')
}
local curBaseTex = tex_analog_base[1]
local curStickTex = tex_analog_stick[1]

local analogStickX = 0
local analogStickY = 0
local stickAxisX = 0
local stickAxisY = 0

function print_text_rtl(text, x, y, scale)
	x = x - djui_hud_measure_text(text)
	return djui_hud_print_text(text, x, y, scale)
end
function print_text_centered(text, x, y, scale)
	x = x - djui_hud_measure_text(text) / 2
	return djui_hud_print_text(text, x, y, scale)
end

function djui_hud_render_texture_centered(tex, x, y, scale)
  x = x - (tex.width * scale) / 2
  y = y - (tex.height * scale) / 2
  return djui_hud_render_texture(tex, x, y, scale, scale)
end

function hud_render_behind()
	local m = gMarioStates[0]
	
	djui_hud_set_resolution(RESOLUTION_N64)
	djui_hud_set_font(FONT_HUD)
	screenW, screenH = djui_hud_get_screen_width(), djui_hud_get_screen_height()
	
	-- render boring useless numbers...
	if not inMenu then
		if c_input_stick == 2 or c_input_stick == 4 then
			local stickDirectionY
			local stickDirectionX
			
			if stickAxisY > 0 then
				stickDirectionY = "U" -- UP
			elseif stickAxisY < 0 then
				stickDirectionY = "D" -- DOWN
			else
				stickDirectionY = " "
			end
			if stickAxisX > 0 then
				stickDirectionX = "R" -- RIGHT
			elseif stickAxisX < 0 then
				stickDirectionX = "L" -- LEFT
			else
				stickDirectionX = " "
			end
			
			djui_hud_print_text(stickDirectionY..tostring(stickAxisY):gsub("%-", ""), 20, screenH - 50, 1)
			djui_hud_print_text(stickDirectionX..tostring(stickAxisX):gsub("%-", ""), 20, screenH - 30, 1)
		end
		
		-- render stick and base
		if c_input_stick == 3 or c_input_stick == 4 then
			djui_hud_render_texture_centered(curBaseTex, 40, screenH - 32, 1, 1)
			djui_hud_render_texture_centered(curStickTex, 40 + analogStickX, (screenH - 32) + analogStickY, 1, 1)
		end
	end
end

function update()
	local m = gMarioStates[0]
	isPaused = is_game_paused()
	
	-- update boring numbers.. who cares...
	if c_input_axis == 1 then
		stickAxisX = math.floor(m.controller.rawStickX)
		stickAxisY = math.floor(m.controller.rawStickY)
	else
		-- a bit closer to original usamune
		stickAxisX = math.floor(m.controller.rawStickX * 0.68)
		stickAxisY = math.floor(m.controller.rawStickY * 0.68)
	end
	
	-- update stick base
	if c_input_stickbg == 2 then
		curBaseTex = tex_analog_base[2]
		analogStickX = (m.controller.stickX - 0) * 0.237
		analogStickY = (0 - m.controller.stickY) * 0.237
	else
		curBaseTex = tex_analog_base[1]
		analogStickX = (m.controller.rawStickX - 0) * 0.118
		analogStickY = (0 - m.controller.rawStickY) * 0.118
	end
	-- update stick
	if c_input_stickVar == 2 then
		curStickTex = tex_analog_stick[2]
	else
		curStickTex = tex_analog_stick[1]
	end
end

hook_event(HOOK_ON_HUD_RENDER_BEHIND, hud_render_behind)
hook_event(HOOK_UPDATE, update)