-- name: Omm Sparkles  
-- description: Omm Sparkles  
  
-- Usar pink star como modelo  
E_MODEL_OMM_STAR = smlua_model_util_get_id("pink_star") or smlua_model_util_get_id("sparkle_star") or smlua_model_util_get_id("star")  
  
-- Variables globales para sistema OMM  
local previousPos = {x = 0, y = 0, z = 0}  
local globalTimer = 0  
  
hook_event(HOOK_MARIO_UPDATE, function(m)   
    local s = gPlayerSyncTable[m.playerIndex]  
    if m.playerIndex ~= 0 then return end  
    if network_is_server() then s.host = true else s.host = false end  
      
    -- Condiciones simplificadas para asegurar spawn  
    if not s.host then return end  
      
    -- Calcular velocidad para frecuencia dinámica (fórmula OMM exacta)  
    local vel = math.sqrt((m.pos.x - previousPos.x)^2 +   
                         (m.pos.y - previousPos.y)^2 +   
                         (m.pos.z - previousPos.z)^2)  
      
    -- Frecuencia dinámica OMM exacta (3 - clamp_s(vel / 25.f, 0, 2))  
    local interval = 3 - math.min(math.max(vel / 25.0, 0), 2)  
    if globalTimer % math.floor(interval) == 0 then  
        spawn_pink_star_sparkle(m)  
    end  
      
    -- Actualizar posición anterior  
    previousPos = {x = m.pos.x, y = m.pos.y, z = m.pos.z}  
    globalTimer = globalTimer + 1  
end)  
  
-- Resetear contadores al inicializar el nivel  
hook_event(HOOK_ON_LEVEL_INIT, function()  
    globalTimer = 0  
    previousPos = {x = 0, y = 0, z = 0}  
end)  
  
function spawn_pink_star_sparkle(m)  
    -- Posición base de Mario (similar a root position)  
    local spawnX = m.pos.x  
    local spawnY = m.pos.y + 50 -- offset vertical similar al sistema OMM  
    local spawnZ = m.pos.z  
      
    spawn_non_sync_object(  
        id_bhvPinkStarSparkles,  
        E_MODEL_OMM_STAR,  
        spawnX, spawnY, spawnZ,  
        function(o)  
            -- Parámetros OMM exactos  
            local sparkleVel = 10  
            o.oVelX = sparkleVel * (math.random() - 0.5)  
            o.oVelY = sparkleVel * (math.random() - 0.5)  
            o.oVelZ = sparkleVel * (math.random() - 0.5)  
            o.oScale = 0.4 -- Escala OMM exacta  
            o.oAction = 30 -- Lifetime OMM exacto  
            o.oAnimState = math.random(0, 1)  
              
            -- Offset inicial basado en velocidad (cálculo OMM)  
            local dv = math.sqrt(o.oVelX^2 + o.oVelY^2 + o.oVelZ^2)  
            local offset = 30 -- offset OMM  
            if dv ~= 0 then  
                o.oHomeX = offset * (o.oVelX / dv)  
                o.oHomeY = offset * (o.oVelY / dv)  
                o.oHomeZ = offset * (o.oVelZ / dv)  
            else  
                o.oHomeX = 0  
                o.oHomeY = 0  
                o.oHomeZ = 0  
            end  
              
            -- Ajuste post-spawn para alineación con Mario  
            o.oPosX = m.pos.x + o.oHomeX  
            o.oPosY = m.pos.y + 50 + o.oHomeY  
            o.oPosZ = m.pos.z + o.oHomeZ  
        end  
    )  
end  
  
define_custom_obj_fields({  
    oScale = 'f32',  
})  
  
function pink_star_sparkle_init(o)  
    o.oFlags = OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE  
    o.oAnimState = math.random(0, 1)  
    cur_obj_scale(o.oScale)  
end  
  
function pink_star_sparkle_loop(o, a)  
    obj_set_billboard(o)  
      
    -- Movimiento relativo al padre (Mario) - lógica OMM exacta  
    if o.parentObj ~= o then  
        o.oPosX = o.parentObj.oPosX + o.oHomeX + o.oVelX * o.oTimer  
        o.oPosY = o.parentObj.oPosY + o.oHomeY + o.oVelY * o.oTimer  
        o.oPosZ = o.parentObj.oPosZ + o.oHomeZ + o.oVelZ * o.oTimer  
    else  
        o.oPosX = o.oPosX + o.oVelX  
        o.oPosY = o.oPosY + o.oVelY  
        o.oPosZ = o.oPosZ + o.oVelZ  
    end  
      
    -- Animación  
    o.oAnimState = o.oAnimState + 1  
      
    -- Eliminación después de ciclo fijo  
    if o.oTimer > o.oAction then  
        obj_mark_for_deletion(o)  
    end  
end  
  
id_bhvPinkStarSparkles = hook_behavior(nil, OBJ_LIST_UNIMPORTANT, true, pink_star_sparkle_init, pink_star_sparkle_loop)